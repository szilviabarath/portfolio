# JsTagSphere

A small script to create the spherical tag cloud with funny scrolling effect when hovering
with mouse. See live demo here: https://rodiongork.github.io/JsTagSphere/

Beware for though it is funny, it may be not extremely convenient for end-users.
E.g. if you create list of content, it would be good to provide some alternatives form also,
like a table :)

Feel free to download files separately or at once in a zip.
Also you could just use the script directly from your html, e.g.

    <script src="https://rodiongork.github.io/JsTagSphere/cloud.js"></script>

moved long time ago from [http://jstagsphere.sf.net](http://jstagsphere.sf.net)
